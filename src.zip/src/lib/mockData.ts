export interface Article {
    id: string;
    title: string;
    slug: string;
    excerpt: string;
    category: string;
    featuredImage: string;
    publishedAt: string;
    readTime?: string;
    author?: string;
}

export class MockNewsData {
    static heroArticle: Article = {
        id: "hero-1",
        title: "U.S. House Passes Major Infrastructure Bill in Bipartisan Vote",
        slug: "us-house-passes-major-infrastructure-bill",
        excerpt: "The $1.2 trillion bill aims to modernize roads, bridges, and public transportation across the country.",
        category: "POLITICS",
        featuredImage: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=1200&q=80",
        publishedAt: "2 hours ago",
    };

    static middleArticles: Article[] = [
        {
            id: "mid-1",
            title: "Stock Markets Rally After Positive Inflation Report",
            slug: "stock-markets-rally-after-positive-inflation-report",
            excerpt: "",
            category: "BUSINESS",
            featuredImage: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=400&q=80",
            publishedAt: "1 hour ago",
        },
        {
            id: "mid-2",
            title: "Lakers Win Thriller Game 7, Advance to Conference Finals",
            slug: "lakers-win-thriller-game-7",
            excerpt: "",
            category: "SPORTS",
            featuredImage: "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=400&q=80",
            publishedAt: "2 hours ago",
        },
        {
            id: "mid-3",
            title: "Apple Unveils New iPhone Series with AI Features",
            slug: "apple-unveils-new-iphone-series-ai-features",
            excerpt: "",
            category: "TECH",
            featuredImage: "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=400&q=80",
            publishedAt: "3 hours ago",
        },
        {
            id: "mid-4",
            title: "CDC Reports Decline in Flu Cases Across the U.S.",
            slug: "cdc-reports-decline-flu-cases",
            excerpt: "",
            category: "HEALTH",
            featuredImage: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=400&q=80",
            publishedAt: "4 hours ago",
        },
    ];

    static breakingList = [
        { time: "10:15 AM", title: "Federal Reserve Signals Potential Interest Rate Cut" },
        { time: "09:45 AM", title: "U.S. Energy Department Announces Renewable Energy Grants" },
        { time: "09:30 AM", title: "Tech Sector Leads Early Morning Wall Street Rally" },
    ];

    static topStories: Article[] = [
        {
            id: "top-1",
            title: "Memorial Day Events Honoring Our Heroes Across the Nation",
            slug: "memorial-day-events-honoring-heroes",
            excerpt: "",
            category: "U.S. NEWS",
            featuredImage: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=500&q=80",
            publishedAt: "5 hours ago",
        },
        {
            id: "top-2",
            title: "G7 Leaders Meet to Discuss Global Economic Challenges",
            slug: "g7-leaders-meet-global-economic-challenges",
            excerpt: "",
            category: "WORLD",
            featuredImage: "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=500&q=80",
            publishedAt: "6 hours ago",
        },
        {
            id: "top-3",
            title: "Wall Street Ends Higher as Tech Stocks Lead Market Gains",
            slug: "wall-street-ends-higher-tech-stocks",
            excerpt: "",
            category: "BUSINESS",
            featuredImage: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=500&q=80",
            publishedAt: "7 hours ago",
        },
        {
            id: "top-4",
            title: "OpenAI Launches New AI Model for Business Solutions",
            slug: "openai-launches-new-ai-model-business",
            excerpt: "",
            category: "TECH",
            featuredImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=500&q=80",
            publishedAt: "8 hours ago",
        },
    ];

    static popularArticles: Article[] = [
        {
            id: "pop-1",
            title: "How the New Tax Plan Will Affect American Families",
            slug: "how-new-tax-plan-affects-families",
            excerpt: "",
            category: "",
            featuredImage: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=300&q=80",
            publishedAt: "12 hours ago",
        },
        {
            id: "pop-2",
            title: "5 Things to Know About the U.S. Job Market in 2026",
            slug: "5-things-to-know-us-job-market",
            excerpt: "",
            category: "",
            featuredImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=300&q=80",
            publishedAt: "14 hours ago",
        },
        {
            id: "pop-3",
            title: "Best National Parks to Visit This Summer",
            slug: "best-national-parks-to-visit-this-summer",
            excerpt: "",
            category: "",
            featuredImage: "https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=300&q=80",
            publishedAt: "16 hours ago",
        },
    ];
}
