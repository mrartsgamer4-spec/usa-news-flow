import { NextResponse } from "next/server";

export async function POST(req: Request) {
    try {
        const { password } = await req.json();
        const correctPassword = process.env.ADMIN_PASSWORD;

        if (password === correctPassword) {
            const response = NextResponse.json({ success: true, message: "Authenticated successfully" });

            // সিকিউর HTTP-Only কুকি সেট করা হচ্ছে
            response.cookies.set("admin_session", "authenticated_true", {
                httpOnly: true,
                secure: process.env.NODE_ENV === "production",
                sameSite: "strict",
                maxAge: 60 * 60 * 24, // ১ দিন
                path: "/",
            });

            return response;
        }

        return NextResponse.json({ success: false, message: "Invalid Password" }, { status: 401 });
    } catch (error) {
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}