import Link from "next/link";
import Image from "next/image";
import { Clock } from "lucide-react";
import { MockNewsData } from "@/lib/mockData";

interface PageProps {
    params: Promise<{
        category: string;
    }>;
}

export default async function CategoryPage({ params }: PageProps) {
    const resolvedParams = await params;
    const currentCategorySlug = resolvedParams.category.toLowerCase();
    const categoryName = decodeURIComponent(resolvedParams.category).replace(/-/g, " ");

    // ১. সব ফেক আর্টিকেলের একটি লিস্ট তৈরি
    const allArticles = [
        MockNewsData.heroArticle,
        ...MockNewsData.middleArticles,
        ...MockNewsData.topStories,
        ...MockNewsData.popularArticles,
    ];

    // ২. ক্যাটাগরি অনুযায়ী ফিল্টার করার লজিক
    const filteredArticles = allArticles.filter((article) => {
        if (!article.category) return true; // ক্যাটাগরি না থাকলে শো করবে
        const artCat = article.category.toLowerCase().replace(/\s+/g, "-");
        return artCat.includes(currentCategorySlug) || currentCategorySlug.includes(artCat);
    });

    // ফিল্টার করে যদি কোনো খবর না পাওয়া যায়, তবে সব খবর দেখাবে (ফ্রি ফোলব্যাক)
    const displayArticles = filteredArticles.length > 0 ? filteredArticles : allArticles;

    return (
        <div className="space-y-6 py-6">
            {/* Category Title Header */}
            <div className="border-b-2 border-news-red pb-2 flex justify-between items-center">
                <h1 className="text-2xl font-serif font-bold uppercase text-news-black tracking-wide">
                    {categoryName}
                </h1>
                <span className="text-xs text-news-gray">
                    Showing {displayArticles.length} articles
                </span>
            </div>

            {/* Articles Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {displayArticles.map((article, idx) => (
                    <Link
                        key={idx}
                        href={`/news/${currentCategorySlug}/${article.slug}`}
                        className="group space-y-2 border border-news-border rounded p-2 hover:shadow-md transition bg-white flex flex-col justify-between"
                    >
                        <div className="space-y-2">
                            <div className="relative aspect-[4/3] w-full rounded overflow-hidden bg-gray-100">
                                <Image
                                    src={article.featuredImage}
                                    alt={article.title}
                                    fill
                                    className="object-cover group-hover:scale-105 transition duration-300"
                                />
                            </div>
                            <span className="text-[10px] font-bold text-news-red uppercase tracking-wider block">
                                {article.category || categoryName}
                            </span>
                            <h2 className="font-serif font-bold text-sm text-news-black group-hover:text-news-red line-clamp-2 leading-snug">
                                {article.title}
                            </h2>
                        </div>

                        <div className="flex items-center gap-1 text-[11px] text-news-gray pt-2 border-t border-gray-100 mt-2">
                            <Clock size={11} />
                            <span>{article.publishedAt}</span>
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    );
}