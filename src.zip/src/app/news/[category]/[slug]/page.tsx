import Image from "next/image";
import { Clock, User, Share2 } from "lucide-react";
import { MockNewsData } from "@/lib/mockData";

interface PageProps {
    params: Promise<{
        category: string;
        slug: string;
    }>;
}

export default async function ArticleDetailsPage({ params }: PageProps) {
    const resolvedParams = await params;
    const article = MockNewsData.heroArticle;

    return (
        <article className="max-w-4xl mx-auto py-8 space-y-6">
            <div className="space-y-3">
                <span className="bg-news-red text-white text-xs font-bold uppercase px-2.5 py-1 rounded-sm">
                    {decodeURIComponent(resolvedParams.category).replace(/-/g, " ")}
                </span>
                <h1 className="text-3xl md:text-5xl font-serif font-bold text-news-black leading-tight">
                    {article.title}
                </h1>

                <div className="flex items-center justify-between text-xs text-news-gray border-y border-news-border py-3">
                    <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1 font-semibold text-news-black">
                            <User size={14} /> By Editorial Staff
                        </span>
                        <span className="flex items-center gap-1">
                            <Clock size={14} /> {article.publishedAt}
                        </span>
                    </div>
                    <button className="flex items-center gap-1 text-news-black hover:text-news-red">
                        <Share2 size={14} /> Share
                    </button>
                </div>
            </div>

            <div className="relative aspect-[16/9] w-full rounded-lg overflow-hidden bg-gray-100">
                <Image
                    src={article.featuredImage}
                    alt={article.title}
                    fill
                    priority
                    className="object-cover"
                />
            </div>

            <div className="prose max-w-none font-serif text-lg text-gray-800 leading-relaxed space-y-4">
                <p className="font-semibold text-xl text-gray-900">{article.excerpt}</p>
                <p>
                    WASHINGTON — The legislation represents one of the most significant federal investments in public infrastructure in decades, aiming to modernize transportation networks, power grids, and broadband access across all 50 states.
                </p>
            </div>
        </article>
    );
}