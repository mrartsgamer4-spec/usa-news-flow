'use client';

import { useState, useEffect } from "react";
import { PlusCircle, Edit, Trash2 } from "lucide-react";
import { MockNewsData } from "@/lib/mockData";

interface ArticleForm {
    id?: string;
    title: string;
    slug: string;
    reporterName: string;
    featuredImage: string;
    imageCaption: string;
    category: string;
    content: string;
    publishedAt?: string;
}

export default function AdminDashboard() {
    const [articles, setArticles] = useState<ArticleForm[]>([]);
    const [editingId, setEditingId] = useState<string | null>(null);

    const [formData, setFormData] = useState<ArticleForm>({
        title: "",
        slug: "",
        reporterName: "",
        featuredImage: "",
        imageCaption: "",
        category: "Politics",
        content: "",
    });

    // ১. পেজ লোড হওয়ার সময় LocalStorage থেকে ডাটা রিড করা
    useEffect(() => {
        const savedArticles = localStorage.getItem("news_articles");
        if (savedArticles) {
            setArticles(JSON.parse(savedArticles));
        } else {
            // যদি আগে থেকে পোস্ট না থাকে, তবে ডামি ডাটা দিয়ে সেট করা
            const initialArticles = [
                MockNewsData.heroArticle,
                ...MockNewsData.middleArticles,
            ].map((item, idx) => ({
                id: String(idx + 1),
                title: item.title,
                slug: item.slug,
                reporterName: "Editorial Staff",
                featuredImage: item.featuredImage,
                imageCaption: item.title,
                category: item.category || "Politics",
                content: item.excerpt,
                publishedAt: item.publishedAt,
            }));
            setArticles(initialArticles);
            localStorage.setItem("news_articles", JSON.stringify(initialArticles));
        }
    }, []);

    // ২. পোস্ট সেভ বা আপডেট করা
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        const slug = formData.title
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/(^-|-$)+/g, "");

        let updatedArticles: ArticleForm[];

        if (editingId) {
            // এডিট আপডেট লজিক
            updatedArticles = articles.map((art) =>
                art.id === editingId ? { ...formData, id: editingId, slug } : art
            );
            setEditingId(null);
        } else {
            // নতুন পোস্ট লজিক
            const newArticle = {
                ...formData,
                id: Date.now().toString(),
                slug,
                publishedAt: "Just now",
            };
            updatedArticles = [newArticle, ...articles];
        }

        setArticles(updatedArticles);
        localStorage.setItem("news_articles", JSON.stringify(updatedArticles));

        // ফর্ম রিসেট
        setFormData({
            title: "",
            slug: "",
            reporterName: "",
            featuredImage: "",
            imageCaption: "",
            category: "Politics",
            content: "",
        });
    };

    // ৩. এডিট বাটনে ক্লিক করলে ফর্মে ডাটা লোড হওয়া
    const handleEdit = (article: ArticleForm) => {
        setEditingId(article.id || null);
        setFormData(article);
        window.scrollTo({ top: 0, behavior: "smooth" }); // ফর্মে স্ক্রোল করে নিয়ে যাবে
    };

    // ৪. ডিলিট করা
    const handleDelete = (id: string) => {
        if (confirm("Are you sure you want to delete this article?")) {
            const filtered = articles.filter((a) => a.id !== id);
            setArticles(filtered);
            localStorage.setItem("news_articles", JSON.stringify(filtered));
        }
    };

    return (
        <div className="py-8 space-y-8 max-w-6xl mx-auto px-4">
            <div className="border-b pb-4 flex justify-between items-center">
                <h1 className="text-2xl font-serif font-bold text-news-black">News Admin Dashboard</h1>
                <span className="text-xs bg-green-100 text-green-800 font-semibold px-3 py-1 rounded-full">
                    Total Posted: {articles.length}
                </span>
            </div>

            {/* নিউজ পোস্ট/এডিট ফর্ম */}
            <form onSubmit={handleSubmit} className="bg-white border border-gray-200 p-6 rounded-lg shadow-sm space-y-4">
                <h2 className="font-bold text-lg text-news-black flex items-center gap-2 border-b pb-2">
                    <PlusCircle size={18} className="text-news-red" />
                    {editingId ? "Edit Article" : "Create New Article"}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                        <label className="block text-xs font-bold text-gray-700 mb-1">Article Title *</label>
                        <input
                            type="text"
                            value={formData.title}
                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                            placeholder="Enter news title in English"
                            className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1">Reporter Name (English) *</label>
                        <input
                            type="text"
                            value={formData.reporterName}
                            onChange={(e) => setFormData({ ...formData, reporterName: e.target.value })}
                            placeholder="e.g. John Doe"
                            className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1">Category *</label>
                        <select
                            value={formData.category}
                            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                            className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                        >
                            <option value="Politics">Politics</option>
                            <option value="U.S. News">U.S. News</option>
                            <option value="World">World</option>
                            <option value="Business">Business</option>
                            <option value="Technology">Technology</option>
                            <option value="Sports">Sports</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1">Featured Image URL *</label>
                        <input
                            type="url"
                            value={formData.featuredImage}
                            onChange={(e) => setFormData({ ...formData, featuredImage: e.target.value })}
                            placeholder="https://images.unsplash.com/..."
                            className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1">Image Caption *</label>
                        <input
                            type="text"
                            value={formData.imageCaption}
                            onChange={(e) => setFormData({ ...formData, imageCaption: e.target.value })}
                            placeholder="Brief description of the image"
                            className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                            required
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Full Article Description *</label>
                    <textarea
                        rows={5}
                        value={formData.content}
                        onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                        placeholder="Write the detailed news story here..."
                        className="w-full border p-2 rounded text-sm focus:outline-none focus:border-news-red"
                        required
                    />
                </div>

                <div className="flex gap-2">
                    <button type="submit" className="bg-news-red text-white px-6 py-2 rounded font-bold text-sm hover:bg-red-700 transition">
                        {editingId ? "Update News" : "Publish News"}
                    </button>
                    {editingId && (
                        <button
                            type="button"
                            onClick={() => {
                                setEditingId(null);
                                setFormData({ title: "", slug: "", reporterName: "", featuredImage: "", imageCaption: "", category: "Politics", content: "" });
                            }}
                            className="bg-gray-300 text-gray-700 px-4 py-2 rounded text-sm font-semibold"
                        >
                            Cancel Edit
                        </button>
                    )}
                </div>
            </form>

            {/* নিউজ তালিকা */}
            <div className="bg-white border border-gray-200 p-6 rounded-lg shadow-sm space-y-4">
                <h2 className="font-bold text-lg text-news-black border-b pb-2">Published Articles ({articles.length})</h2>
                {articles.length === 0 ? (
                    <p className="text-sm text-gray-500 py-4 text-center">No articles found.</p>
                ) : (
                    <div className="divide-y divide-gray-100">
                        {articles.map((item) => (
                            <div key={item.id} className="py-3 flex items-center justify-between gap-4">
                                <div className="space-y-1">
                                    <h3 className="font-bold text-sm text-news-black">{item.title}</h3>
                                    <p className="text-xs text-gray-500">By {item.reporterName} | Category: {item.category}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={() => handleEdit(item)}
                                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded flex items-center gap-1 text-xs font-bold"
                                    >
                                        <Edit size={16} /> Edit
                                    </button>
                                    <button
                                        onClick={() => handleDelete(item.id!)}
                                        className="p-1.5 text-red-600 hover:bg-red-50 rounded flex items-center gap-1 text-xs font-bold"
                                    >
                                        <Trash2 size={16} /> Delete
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}