import Link from "next/link";
import Image from "next/image";
import { Clock, CloudSun, ArrowRight } from "lucide-react";
import { MockNewsData } from "@/lib/mockData";

export default function HomePage() {
    const hero = MockNewsData.heroArticle;
    const middle = MockNewsData.middleArticles;
    const breaking = MockNewsData.breakingList;
    const topStories = MockNewsData.topStories;
    const popular = MockNewsData.popularArticles;

    return (
        <div className="space-y-10 py-4">
            {/* SECTION 1: TOP HERO & SIDEBAR GRID */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                {/* Left Column: Big Hero Banner (6 Cols) */}
                <div className="lg:col-span-6 relative group overflow-hidden rounded-md bg-black">
                    <Link href={`/news/${hero.slug}`} className="block relative aspect-[4/3] w-full">
                        <Image
                            src={hero.featuredImage}
                            alt={hero.title}
                            fill
                            priority
                            className="object-cover opacity-90 group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-6">
                            <span className="bg-news-red text-white text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 w-max rounded-sm mb-2">
                                {hero.category}
                            </span>
                            <h1 className="text-2xl md:text-3xl font-serif font-bold text-white group-hover:text-red-400 transition leading-snug mb-2">
                                {hero.title}
                            </h1>
                            <p className="text-gray-200 text-sm line-clamp-2 mb-3">
                                {hero.excerpt}
                            </p>
                            <div className="flex items-center gap-1.5 text-xs text-gray-300">
                                <Clock size={13} />
                                <span>{hero.publishedAt}</span>
                            </div>
                        </div>
                    </Link>
                </div>

                {/* Middle Column: 4 Small Articles Stacked (3 Cols) */}
                <div className="lg:col-span-3 space-y-4">
                    {middle.map((item) => (
                        <Link key={item.id} href={`/news/${item.slug}`} className="group flex gap-3 items-center">
                            <div className="relative w-24 h-16 shrink-0 rounded overflow-hidden bg-gray-100 border border-news-border">
                                <Image
                                    src={item.featuredImage}
                                    alt={item.title}
                                    fill
                                    className="object-cover group-hover:scale-105 transition duration-300"
                                />
                            </div>
                            <div className="space-y-1">
                                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">
                                    {item.category}
                                </span>
                                <h3 className="font-serif font-bold text-xs leading-tight text-news-black group-hover:text-news-red line-clamp-2">
                                    {item.title}
                                </h3>
                                <div className="flex items-center gap-1 text-[11px] text-news-gray">
                                    <Clock size={11} />
                                    <span>{item.publishedAt}</span>
                                </div>
                            </div>
                        </Link>
                    ))}
                </div>

                {/* Right Column: Breaking News List + Weather Widget (3 Cols) */}
                <div className="lg:col-span-3 space-y-6">
                    {/* Breaking News Box */}
                    <div className="border border-news-border rounded p-4 bg-white shadow-sm">
                        <div className="bg-news-red text-white text-xs font-bold uppercase px-2.5 py-1 w-max rounded-sm mb-3">
                            BREAKING NEWS
                        </div>
                        <div className="space-y-3 divide-y divide-gray-100">
                            {breaking.map((item, i) => (
                                <div key={i} className={`${i !== 0 ? "pt-2.5" : ""} space-y-0.5`}>
                                    <span className="text-news-red text-[11px] font-bold">{item.time}</span>
                                    <p className="text-xs font-serif font-semibold text-news-black hover:text-news-red cursor-pointer line-clamp-2">
                                        {item.title}
                                    </p>
                                </div>
                            ))}
                        </div>
                        <Link href="/news" className="text-xs font-bold text-news-red hover:underline flex items-center gap-1 mt-4">
                            View All Breaking News <ArrowRight size={12} />
                        </Link>
                    </div>

                    {/* Weather Widget Box */}
                    <div className="border border-news-border rounded p-4 bg-gray-50/60">
                        <h4 className="text-xs font-bold uppercase text-news-gray tracking-wider mb-2">
                            WEATHER – NEW YORK
                        </h4>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <CloudSun size={36} className="text-gray-600" />
                                <div>
                                    <div className="text-2xl font-bold text-news-black leading-none">18°C</div>
                                    <div className="text-xs text-news-gray mt-1">Cloudy</div>
                                </div>
                            </div>
                            <div className="text-right text-[11px] text-news-gray space-y-0.5">
                                <div>Humidity: 72%</div>
                                <div>Wind: 12 km/h</div>
                                <div>Feels like: 17°C</div>
                            </div>
                        </div>
                        <Link href="#" className="text-xs font-bold text-news-red hover:underline flex items-center justify-end gap-1 mt-3">
                            View Full Forecast <ArrowRight size={12} />
                        </Link>
                    </div>
                </div>

            </section>

            {/* SECTION 2: TOP STORIES & POPULAR ARTICLES */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 border-t border-news-border pt-6">

                {/* Left Part: TOP STORIES (8 Cols) */}
                <div className="lg:col-span-8 space-y-4">
                    <div className="flex items-center gap-2 border-l-4 border-news-red pl-2">
                        <h2 className="font-serif font-bold text-lg text-news-black uppercase tracking-wider">
                            TOP STORIES
                        </h2>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                        {topStories.map((story) => (
                            <Link key={story.id} href={`/news/${story.slug}`} className="group space-y-2">
                                <div className="relative aspect-[4/3] w-full rounded overflow-hidden bg-gray-100 border border-news-border">
                                    <Image
                                        src={story.featuredImage}
                                        alt={story.title}
                                        fill
                                        className="object-cover group-hover:scale-105 transition duration-300"
                                    />
                                    <span className="absolute top-1.5 left-1.5 bg-news-red text-white text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-sm">
                                        {story.category}
                                    </span>
                                </div>
                                <h3 className="font-serif font-bold text-xs text-news-black group-hover:text-news-red line-clamp-3 leading-snug">
                                    {story.title}
                                </h3>
                                <div className="flex items-center gap-1 text-[10px] text-news-gray">
                                    <Clock size={10} />
                                    <span>{story.publishedAt}</span>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>

                {/* Right Part: POPULAR ARTICLES (4 Cols) */}
                <div className="lg:col-span-4 space-y-4">
                    <div className="flex items-center gap-2 border-l-4 border-news-red pl-2">
                        <h2 className="font-serif font-bold text-lg text-news-black uppercase tracking-wider">
                            POPULAR ARTICLES
                        </h2>
                    </div>

                    <div className="space-y-4">
                        {popular.map((item, index) => (
                            <Link key={item.id} href={`/news/${item.slug}`} className="group flex items-center gap-3">
                                <span className="w-6 h-6 rounded-full bg-news-red text-white flex items-center justify-center font-bold text-xs shrink-0">
                                    {index + 1}
                                </span>
                                <div className="flex-grow">
                                    <h3 className="font-serif font-bold text-xs text-news-black group-hover:text-news-red line-clamp-2 leading-snug">
                                        {item.title}
                                    </h3>
                                    <div className="flex items-center gap-1 text-[10px] text-news-gray mt-1">
                                        <Clock size={10} />
                                        <span>{item.publishedAt}</span>
                                    </div>
                                </div>
                                <div className="relative w-16 h-12 shrink-0 rounded overflow-hidden bg-gray-100 border border-news-border">
                                    <Image
                                        src={item.featuredImage}
                                        alt={item.title}
                                        fill
                                        className="object-cover group-hover:scale-105 transition duration-300"
                                    />
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>

            </section>
        </div>
    );
}