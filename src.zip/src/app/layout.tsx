import type { Metadata } from "next";
import { Inter, Merriweather } from "next/font/google";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import "@/app/globals.css";

const inter = Inter({
    subsets: ["latin"],
    variable: "--font-inter",
});

const merriweather = Merriweather({
    weight: ["300", "400", "700", "900"],
    subsets: ["latin"],
    variable: "--font-merriweather",
});

export const metadata: Metadata = {
    title: "USA NEWS FLOW - Your Daily Flow of U.S. News & Insights",
    description: "USA News Flow delivers real-time breaking news, politics, business, technology, sports, and world coverage.",
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" className={`${inter.variable} ${merriweather.variable}`}>
            <body className="bg-white text-news-black font-sans antialiased min-h-screen flex flex-col justify-between">
                <div>
                    <Header />
                    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        {children}
                    </main>
                </div>
                <Footer />
            </body>
        </html>
    );
}