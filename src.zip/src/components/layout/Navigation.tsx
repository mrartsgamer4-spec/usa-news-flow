"use client";

import Link from "next/link";
import { useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";

const NAV_ITEMS = [
    { label: "Home", href: "/" },
    {
        label: "U.S. News",
        href: "/news",
        sub: [
            { label: "Breaking News", href: "/news/breaking" },
            { label: "California", href: "/news/california" },
            { label: "New York", href: "/news/new-york" },
            { label: "Texas", href: "/news/texas" },
            { label: "Florida", href: "/news/florida" },
        ],
    },
    {
        label: "Politics",
        href: "/politics",
        sub: [
            { label: "White House", href: "/politics/white-house" },
            { label: "Congress", href: "/politics/congress" },
            { label: "Elections", href: "/politics/elections" },
        ],
    },
    { label: "World", href: "/world" },
    { label: "Business", href: "/business" },
    { label: "Technology", href: "/technology" },
    { label: "Health", href: "/health" },
    { label: "Sports", href: "/sports" },
    {
        label: "Tools",
        href: "/tools",
        sub: [
            { label: "PDF Tools", href: "/tools/pdf" },
            { label: "Image Tools", href: "/tools/image" },
            { label: "QR Code Generator", href: "/tools/qr-code-generator" },
        ],
    },
    {
        label: "Calculators",
        href: "/calculators",
        sub: [
            { label: "Salary Calculator", href: "/calculators/salary-calculator" },
            { label: "Loan Calculator", href: "/calculators/loan" },
            { label: "Mortgage Calculator", href: "/calculators/mortgage" },
        ],
    },
];

export default function Navigation() {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    return (
        <nav className="bg-news-red text-white shadow-md relative z-50">
            <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-12">
                {/* Desktop Menu */}
                <div className="hidden lg:flex items-center space-x-1">
                    {NAV_ITEMS.map((item) => (
                        <div key={item.label} className="relative group">
                            <Link
                                href={item.href}
                                className="px-3 py-2 text-sm font-bold uppercase tracking-wider hover:bg-news-darkRed transition flex items-center gap-1 rounded-sm"
                            >
                                {item.label}
                                {item.sub && <ChevronDown size={14} className="opacity-80 group-hover:rotate-180 transition-transform" />}
                            </Link>

                            {item.sub && (
                                <div className="absolute top-full left-0 hidden group-hover:block bg-white text-news-black shadow-xl border border-news-border py-2 min-w-[200px] rounded-b-md z-50">
                                    {item.sub.map((subItem) => (
                                        <Link
                                            key={subItem.label}
                                            href={subItem.href}
                                            className="block px-4 py-2 text-sm font-medium hover:bg-news-lightRed hover:text-news-red transition"
                                        >
                                            {subItem.label}
                                        </Link>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>

                {/* Mobile Toggle Button */}
                <div className="lg:hidden flex items-center justify-between w-full">
                    <span className="text-xs font-bold uppercase tracking-widest text-white/90">Navigation Menu</span>
                    <button
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        className="p-1.5 focus:outline-none hover:bg-news-darkRed rounded"
                        aria-label="Toggle Menu"
                    >
                        {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mobile Slide-out Menu */}
            {mobileMenuOpen && (
                <div className="lg:hidden bg-news-black border-t border-red-800 text-white px-4 py-4 space-y-3 max-h-[80vh] overflow-y-auto">
                    {NAV_ITEMS.map((item) => (
                        <div key={item.label} className="border-b border-gray-800 pb-2">
                            <Link
                                href={item.href}
                                onClick={() => setMobileMenuOpen(false)}
                                className="block text-base font-bold uppercase hover:text-news-red"
                            >
                                {item.label}
                            </Link>
                            {item.sub && (
                                <div className="pl-4 mt-2 space-y-1.5 border-l-2 border-news-red">
                                    {item.sub.map((subItem) => (
                                        <Link
                                            key={subItem.label}
                                            href={subItem.href}
                                            onClick={() => setMobileMenuOpen(false)}
                                            className="block text-sm text-gray-300 hover:text-white"
                                        >
                                            {subItem.label}
                                        </Link>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </nav>
    );
}