'use client';

import Link from "next/link";
import {
    Mail,
    Phone,
    ArrowUp,
    FileText,
    Image as ImageIcon,
    QrCode,
    Type,
    FileType,
    Calculator as CalcIcon,
    Receipt,
    Home,
    Landmark,
    Percent
} from "lucide-react";
import Logo from "./Logo";

export default function Footer() {
    const scrollToTop = () => {
        if (typeof window !== "undefined") {
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    };

    const categories = [
        "Breaking News", "Election 2025", "White House", "Wall Street",
        "AI & Tech", "NFL", "NBA", "Climate Change", "Shootings", "Inflation"
    ];

    return (
        <footer className="bg-[#0b131e] text-gray-300 pt-12 pb-6 border-t border-gray-800 font-sans mt-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">

                {/* Main Footer Content */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 text-sm">

                    {/* Column 1: Brand & Socials */}
                    <div className="lg:col-span-1 space-y-4">
                        <Logo isDarkBg />
                        <p className="text-gray-400 text-xs leading-relaxed">
                            Your trusted source for breaking news, in-depth analysis, and the latest updates from across the United States and around the world.
                        </p>
                     
                    </div>

                    {/* Column 2: Quick Links */}
                    <div className="space-y-3">
                        <h3 className="text-white font-bold uppercase tracking-wider text-xs border-b border-gray-800 pb-2">
                            Quick Links
                        </h3>
                        <div className="grid grid-cols-2 gap-x-2 gap-y-2 text-xs text-gray-400">
                            <Link href="/" className="hover:text-white transition">Home</Link>
                            <Link href="/news/health" className="hover:text-white transition">Health</Link>
                            <Link href="/news/us-news" className="hover:text-white transition">U.S. News</Link>
                            <Link href="/news/entertainment" className="hover:text-white transition">Entertainment</Link>
                            <Link href="/news/politics" className="hover:text-white transition">Politics</Link>
                            <Link href="/news/opinion" className="hover:text-white transition">Opinion</Link>
                            <Link href="/news/world" className="hover:text-white transition">World</Link>
                            <Link href="/tools" className="hover:text-white transition">Tools</Link>
                            <Link href="/news/business" className="hover:text-white transition">Business</Link>
                            <Link href="/calculators" className="hover:text-white transition">Calculators</Link>
                            <Link href="/news/tech" className="hover:text-white transition">Technology</Link>
                            <Link href="/contact" className="hover:text-white transition">Contact Us</Link>
                            <Link href="/news/sports" className="hover:text-white transition">Sports</Link>
                            <Link href="/about" className="hover:text-white transition">About Us</Link>
                        </div>
                    </div>

                    {/* Column 3: Popular Categories */}
                    <div className="space-y-3">
                        <h3 className="text-white font-bold uppercase tracking-wider text-xs border-b border-gray-800 pb-2">
                            Popular Categories
                        </h3>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                            {categories.map((cat, i) => (
                                <span key={i} className="text-[11px] bg-gray-800/80 hover:bg-news-red hover:text-white text-gray-300 px-2.5 py-1 rounded cursor-pointer transition">
                                    {cat}
                                </span>
                            ))}
                        </div>
                    </div>

                    {/* Column 4: Useful Tools */}
                    <div className="space-y-3">
                        <h3 className="text-white font-bold uppercase tracking-wider text-xs border-b border-gray-800 pb-2">
                            Useful Tools
                        </h3>
                        <ul className="space-y-2 text-xs text-gray-400">
                            <li><Link href="/tools/pdf" className="hover:text-white flex items-center gap-2"><FileText size={13} className="text-red-500" /> PDF Tools</Link></li>
                            <li><Link href="/tools/image" className="hover:text-white flex items-center gap-2"><ImageIcon size={13} className="text-blue-400" /> Image Tools</Link></li>
                            <li><Link href="/tools/qr" className="hover:text-white flex items-center gap-2"><QrCode size={13} className="text-green-400" /> QR Code Generator</Link></li>
                            <li><Link href="/tools/text" className="hover:text-white flex items-center gap-2"><Type size={13} className="text-yellow-400" /> Text Tools</Link></li>
                            <li><Link href="/tools/convert" className="hover:text-white flex items-center gap-2"><FileType size={13} className="text-purple-400" /> File Conversion Tools</Link></li>
                        </ul>
                        <Link href="/tools" className="inline-block text-xs text-news-red font-bold hover:underline pt-1">
                            View All Tools &rarr;
                        </Link>
                    </div>

                    {/* Column 5: Calculators */}
                    <div className="space-y-3">
                        <h3 className="text-white font-bold uppercase tracking-wider text-xs border-b border-gray-800 pb-2">
                            Calculators
                        </h3>
                        <ul className="space-y-2 text-xs text-gray-400">
                            <li><Link href="/calculators/salary" className="hover:text-white flex items-center gap-2"><CalcIcon size={13} className="text-emerald-400" /> Salary Calculator</Link></li>
                            <li><Link href="/calculators/tax" className="hover:text-white flex items-center gap-2"><Receipt size={13} className="text-indigo-400" /> Tax Calculator</Link></li>
                            <li><Link href="/calculators/mortgage" className="hover:text-white flex items-center gap-2"><Home size={13} className="text-amber-400" /> Mortgage Calculator</Link></li>
                            <li><Link href="/calculators/loan" className="hover:text-white flex items-center gap-2"><Landmark size={13} className="text-cyan-400" /> Loan Calculator</Link></li>
                            <li><Link href="/calculators/percentage" className="hover:text-white flex items-center gap-2"><Percent size={13} className="text-rose-400" /> Percentage Calculator</Link></li>
                        </ul>
                        <Link href="/calculators" className="inline-block text-xs text-news-red font-bold hover:underline pt-1">
                            View All Calculators &rarr;
                        </Link>
                    </div>

                    {/* Column 6: Policies & Info */}
                    <div className="space-y-3">
                        <h3 className="text-white font-bold uppercase tracking-wider text-xs border-b border-gray-800 pb-2">
                            Policies & Info
                        </h3>
                        <ul className="space-y-2 text-xs text-gray-400">
                            <li><Link href="/about" className="hover:text-white">About Us</Link></li>
                            <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
                            <li><Link href="/terms" className="hover:text-white">Terms of Use</Link></li>
                            <li><Link href="/editorial" className="hover:text-white">Editorial Policy</Link></li>
                            <li><Link href="/advertising" className="hover:text-white">Advertising Policy</Link></li>
                            <li><Link href="/corrections" className="hover:text-white">Corrections Policy</Link></li>
                            <li><Link href="/sitemap" className="hover:text-white">Sitemap</Link></li>
                            <li><Link href="/rss" className="hover:text-white">RSS Feeds</Link></li>
                        </ul>
                    </div>

                </div>

                {/* Bottom Bar */}
                <div className="pt-6 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between text-xs text-gray-400 gap-4">
                    <div className="flex flex-wrap items-center gap-6">
                        <a href="mailto:contact@usanewsflow.com" className="flex items-center gap-1.5 hover:text-white">
                            <Mail size={14} className="text-news-red" /> contact@usanewsflow.com
                        </a>
                        <a href="tel:+12125550198" className="flex items-center gap-1.5 hover:text-white">
                            <Phone size={14} className="text-news-red" /> +1 (212) 555-0198
                        </a>
                    </div>

                    <div>
                        © 2026 USA News Flow. All Rights Reserved.
                    </div>

                    <div className="flex items-center gap-4">
                        <span>made with <span className="text-red-500">❤️</span> for readers in the U.S. and beyond.</span>
                        <button
                            onClick={scrollToTop}
                            className="p-2 bg-gray-800 hover:bg-news-red text-white rounded-full transition shadow-md"
                            aria-label="Scroll to Top"
                        >
                            <ArrowUp size={16} />
                        </button>
                    </div>
                </div>

            </div>
        </footer>
    );
}